Language: Java

Environment: JDK 17

If you have any questions, you can contact me with this email <sunshinesq@163.com>.