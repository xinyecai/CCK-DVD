package algorithm.impl;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

import Jama.Matrix;
import algorithm.util.crossover.DifferentialEvolution;
import algorithm.util.grouping.VariableGrouping;
import algorithm.util.indicator.Hypervolume;
import algorithm.util.mutation.PolynomialMutation;
import algorithm.util.populationsize.DefaultPopulationSizeSet;
import algorithm.util.solutionattribute.CrowdingDistance;
import algorithm.util.solutionattribute.DominanceComparator;
import algorithm.util.solutionattribute.NonDominatedRanking;
import basic.problem.*;
import basic.random.RandomGenerator;
import basic.solution.Solution;
import result.writer.ResultWriteToFile;

/**
 * Define the implementation of BLMOCC
 * 
 * @author Qi Sun <sunshinesq@163.com>
 *
 */
public class BLMOCC {

	private Problem problem;
	private DefaultPopulationSizeSet setter = new DefaultPopulationSizeSet();
	private NonDominatedRanking ranking = new NonDominatedRanking();
	private DifferentialEvolution crossover = new DifferentialEvolution();
	private PolynomialMutation mutation;
	private Hypervolume hv = new Hypervolume();

	private int Nu;
	private int Nl;
	private List<List<Solution>> population;
	private List<Solution> upperArchive;
	private List<List<Solution>> lowerArchives;
	private List<List<Integer>> groups = new ArrayList<>();
	private List<Integer> groupType = new ArrayList<>();
	private double[] idealPoint;
	private int upperEvaluations;
	private int lowerEvaluations;

	private int �� = 10;
	private double epsilonL = 0.001;
	private double epsilonU = 0.001;
	private static int runNum;

	public BLMOCC(Problem problem) {
		this.problem = problem;
		mutation = new PolynomialMutation(problem);
		Nu = setter.getNu(problem);
		Nl = setter.getNl(problem);
		population = new ArrayList<>(Nu);
		upperArchive = new ArrayList<>(Nu * Nl);
		lowerArchives = new ArrayList<>(Nu);
		idealPoint = new double[2];
	}

	public static void main(String[] args) {
		for (runNum = 1; runNum <= 1; runNum++) {
			Problem problem = new DS5();
			new BLMOCC(problem).run();
		}
	}

	public void run() {
		initializePopulation();
		for (List<Solution> popI : population) {
			lowerEvaluatePop(popI);
			ranking.computeRank(popI, 'l');
			lowerArchives.add(ranking.getSubfront(0));
		}
		upperEvaluatePop(mergePopulation(lowerArchives));
		ranking.computeRank(mergePopulation(lowerArchives), 'u');
		upperArchive = ranking.getSubfront(0);
		
		int upperIterations = 0;
		List<List<Solution>> ��UpperArchive = new ArrayList<>(��);

		while (true) {
			upperIterations++;
			System.out.println("��" + upperIterations + "���ϲ����");
			
			KDVD();
			coevolution();

			List<Solution> tempSet = new ArrayList<>();
			tempSet.addAll(upperArchive);
			��UpperArchive.add(tempSet);
			if (upperIterations % �� == 0) {
				if (calcHMetric(��UpperArchive, 'u') <= epsilonU) {
					ResultWriteToFile.saveResults("results/" + problem.getName() + "_run_" + runNum + ".txt",
							upperArchive);
					break;
				} else {
					��UpperArchive.clear();
				}
			}
		}
		System.out.println("�ϲ�����������" + upperEvaluations);
		System.out.println("�²�����������" + lowerEvaluations);
	}
	
	public void KDVD() {
		int row = problem.getNumOfUpperVar() + problem.getNumOfLowerVar();
		int column = problem.getNumOfUpperVar() + problem.getNumOfLowerVar();
		Matrix[] mArray = new Matrix[3];
		for (int i = 0; i < 3; i++) {
			mArray[i] = new Matrix(row, column);
		} 

		updateIdealPoint();
		Solution nearestSolution = getNearestSolution();
		VariableGrouping decomposer = new VariableGrouping(nearestSolution);
		decomposer.setUpperVariedSolutions();
		decomposer.setLowerVariedSolutions();
		decomposer.setBothVariedSolutions();
		lowerEvaluatePop(decomposer.getUpperVariedSolutions());
		lowerEvaluatePop(decomposer.getLowerVariedSolutions());
		lowerEvaluatePop(decomposer.getBothVariedSolutions());
		decomposer.setGroups(mArray);
		decomposer.setGroupType();
		groups = decomposer.getGroups();
		groupType = decomposer.getGroupType();
	}
	
	public void coevolution() {
		List<List<List<Solution>>> SP = new ArrayList<>();
		Solution cv = new Solution(problem);
		for (int i = 0; i < Nu; i++) {
			List<List<Solution>> spI = new ArrayList<>();
			initializeSPi(population.get(i), spI);
			SP.add(spI);
			cv = initializeCV(population.get(i));
			List<List<Solution>> ��LowerArchive = new ArrayList<>(��);

			int lowerIterations = 0;
			while (true) {
				lowerIterations++;
				System.out.println("\t" + "��" + lowerIterations + "���²����");

				for (int j = 0; j < groups.size(); j++) {
					if (groupType.get(j) != 1) {
						optimizer(cv, i, j, spI.get(j), 'l');
						updatePopI(population.get(i), spI.get(j), groups.get(j));
					}
				}
				lowerEvaluatePop(population.get(i));
				ranking.computeRank(population.get(i), 'l');
				for (Solution s : ranking.getSubfront(0)) {
					addToAchive(s, lowerArchives.get(i), 'l');
				}
				
				updateArchive(lowerArchives.get(i), Nl*Nu, 'l');

				List<Solution> tempSet = new ArrayList<>();
				tempSet.addAll(lowerArchives.get(i));
				��LowerArchive.add(tempSet);
				if (lowerIterations % �� == 0) {
					if (calcHMetric(��LowerArchive, 'l') <= epsilonL) {
						break;
					} else {
						��LowerArchive.clear();
					}
				}
			}
			upperEvaluatePop(lowerArchives.get(i));
			ranking.computeRank(lowerArchives.get(i), 'u');
			for (Solution s : ranking.getSubfront(0)) {
				addToAchive(s, upperArchive, 'u');
			}
			updateArchive(upperArchive, Nu * Nl, 'u');
		}

		for (int i = 0; i < Nu; i++) {
			for (int j = 0; j < groups.size(); j++) {
				if (groupType.get(j) != 2) {
					optimizer(cv, i, j, SP.get(i).get(j), 'u');
				}
			}
		}
		
	}

	public void optimizer(Solution cv, int i, int j, List<Solution> spIj, char flag) {
		if (flag == 'l') {
			List<Solution> offsprings = new ArrayList<>();
			for (int num = 0; num < Nl; num++) {
				List<Solution> parents = selectLowerParents(i, num, spIj);
				Solution child = crossover.crossoverLower(parents);
				mutation.mutationLower(child);
				offsprings.add(child);
			}
			offsprings.addAll(spIj);
			for (Solution s : offsprings) {
				replacedCVj(cv, groups.get(j), s);
				evaluateReplacedCV(cv, s);
			}
			calcRankAndDistance(offsprings, flag);
			offsprings = selectHalfSolutions(offsprings);
			spIj.clear();
			spIj.addAll(offsprings);
			updateCV(cv, spIj, groups.get(j), flag);

		} else {
			Solution offspring;
			List<Solution> parents = selectUpperParents(i, spIj);
			offspring = crossover.crossoverUpper(parents);
			mutation.mutationUpper(offspring);
			for (int index : groups.get(j)) {
				if (index < problem.getNumOfUpperVar()) {
					for (int num = 0; num < Nl; num++) {
						population.get(i).get(num).setUpperVariableValue(index, offspring.getUpperVariableValue(index));
					}
				}
			}

		}
	}

	public List<Solution> selectUpperParents(int i, List<Solution> spIj) {
		List<Solution> parents = new ArrayList<>(3);
		parents.add(spIj.get(0));
		while (true) {
			int number = RandomGenerator.nextInt(0, Nu - 1);
			if (number != i) {
				parents.add(population.get(number).get(0));
				break;
			}
		}
		parents.add(upperArchive.get(RandomGenerator.nextInt(0, upperArchive.size() - 1)));

		return parents;
	}

	public double calcHMetric(List<List<Solution>> ��Archive, char flag) {
		double[] nadirPoint = new double[2];// two objective problem
		for (int i = 0; i < 2; i++) {
			nadirPoint[i] = Double.NEGATIVE_INFINITY;
		}
		List<Solution> mergedArchive = mergePopulation(��Archive);
		for (Solution s : mergedArchive) {
			for (int i = 0; i < 2; i++) {
				if (flag == 'l') {
					if (s.getLowerObjective(i) > nadirPoint[i]) {
						nadirPoint[i] = s.getLowerObjective(i);
					}
				} else {
					if (s.getUpperObjective(i) > nadirPoint[i]) {
						nadirPoint[i] = s.getUpperObjective(i);
					}
				}
			}
		}

		double[] HV = new double[��];
		double maxHV = Double.NEGATIVE_INFINITY, minHV = Double.MAX_VALUE;
		for (int i = 0; i < ��; i++) {
			HV[i] = hv.calc2DHV(��Archive.get(i), nadirPoint, flag);
			if (maxHV < HV[i]) {
				maxHV = HV[i];
			}
			if (minHV > HV[i]) {
				minHV = HV[i];
			}
		}

		return (maxHV - minHV) / (maxHV + minHV);

	}

	public void updatePopI(List<Solution> popI, List<Solution> spIj, List<Integer> groupJ) {
		for (int num : groupJ) {
			if (num >= problem.getNumOfUpperVar()) {
				num = num - problem.getNumOfUpperVar();
				for (int i = 0; i < Nl; i++) {
					popI.get(i).setLowerVariableValue(num, spIj.get(i).getLowerVariableValue(num));
				}
			}
		}
	}

	public void updateCV(Solution cv, List<Solution> spIj, List<Integer> groupJ, char flag) {
		calcRankAndDistance(spIj, flag);
		List<Solution> nondominatedFront = ranking.getSubfront(0);
		sortByCrowdingDistance(nondominatedFront, flag);
		Solution bestS;
		if (nondominatedFront.size() <= 2) {
			bestS = nondominatedFront.get(RandomGenerator.nextInt(0, nondominatedFront.size()-1));
		} else {
			bestS = nondominatedFront.get(2);
		}
		replacedCVj(cv, groupJ, bestS);
	}

	public void replacedCVj(Solution cv, List<Integer> groupJ, Solution s) {
		for (int num : groupJ) {
			if (num >= problem.getNumOfUpperVar()) {
				num = num - problem.getNumOfUpperVar();
				cv.setLowerVariableValue(num, s.getLowerVariableValue(num));
			}
		}
	}

	public List<Solution> selectHalfSolutions(List<Solution> solutionSet) {
		List<Solution> halfSolutions = new ArrayList<>();
		int rankIndex = 0;
		while (halfSolutions.size() < Nl) {
			if (ranking.getSubfront(rankIndex).size() <= Nl - halfSolutions.size()) { 
				halfSolutions.addAll(ranking.getSubfront(rankIndex));
				rankIndex++;
			} else {
				List<Solution> currentFront = ranking.getSubfront(rankIndex);
				selectBestSolutions(currentFront, halfSolutions, 'l', Nl);
			}
		}

		return halfSolutions;
	}

	public void evaluateReplacedCV(Solution cv, Solution s) {
		problem.evaluateLowerObj(cv);
		problem.evaluateLowerConstraints(cv);
		lowerEvaluations++;
		for (int i = 0; i < problem.getNumOfLowerObj(); i++) {
			s.setLowerObjective(i, cv.getLowerObjective(i));
		}
		for (int i = 0; i < problem.getNumOfLowerConstraint(); i++) {
			s.setLowerConstraint(i, cv.getLowerConstraint(i));
		}
		s.setLowerConstraintViolationDegree(cv.getLowerConstraintViolationDegree());
	}

	public List<Solution> selectLowerParents(int i, int num, List<Solution> spIj) {
		List<Solution> parents = new ArrayList<>(3);
		parents.add(spIj.get(num));
		while (true) {
			int number = RandomGenerator.nextInt(0, Nl - 1);
			if (number != num) {
				parents.add(spIj.get(number));
				break;
			}
		}
		parents.add(lowerArchives.get(i).get(RandomGenerator.nextInt(0, lowerArchives.get(i).size() - 1)));
		return parents;
	}

	public void initializeSPi(List<Solution> popI, List<List<Solution>> spI) {
		List<Solution> spIj;
		for (int j = 0; j < groups.size(); j++) {
			spIj = new ArrayList<>();
			for (Solution s : popI) {
				spIj.add(s.copy());
			}
			spI.add(spIj);
		}
	}

	public Solution initializeCV(List<Solution> popI) {
		int num = (int) Math.floor(Nl * RandomGenerator.nextDouble(0, 1));
		return popI.get(num).copy();
	}

	public Solution getNearestSolution() {
		Solution nearestSolution = new Solution(problem);
		double distance = Double.MAX_VALUE;
		for (Solution s : upperArchive) {
			double value = 0.0;
			for (int i = 0; i < 2; i++) {
				value += Math.pow(s.getUpperObjective(i) - idealPoint[i], 2);
			}
			if (value < distance) {
				distance = value;
				nearestSolution = s;
			}
		}
		return nearestSolution;
	}

	public void updateIdealPoint() { 
		for (int i = 0; i < 2; i++) {
			idealPoint[i] = Double.MAX_VALUE;
		}
		for (Solution s : upperArchive) {
			for (int i = 0; i < 2; i++) {
				if (s.getUpperObjective(i) < idealPoint[i]) {
					idealPoint[i] = s.getUpperObjective(i);
				}
			}
		}
	}

	public void updateArchive(List<Solution> archive, int maxSize, char flag) {
		CrowdingDistance.computeCrowdingDistance(archive, flag);
		if (archive.size() > maxSize) {
			List<Solution> tempArchive = new ArrayList<>();
			selectBestSolutions(archive, tempArchive, flag, maxSize);
			archive.clear();
			archive.addAll(tempArchive);
		}

	}

	public void selectBestSolutions(List<Solution> solutionSet, List<Solution> tempSet, char flag, int maxSize) {
		sortByCrowdingDistance(solutionSet, flag);
		int i = 0;
		while (tempSet.size() < maxSize) {
			tempSet.add(solutionSet.get(i));
			i++;
		}
	}

	public void sortByCrowdingDistance(List<Solution> solutionSet, char flag) {
		solutionSet.sort(new Comparator<Solution>() {
			@Override
			public int compare(Solution o1, Solution o2) {
				if (flag == 'l') {
					// Sort by CDl in descending order
					return Double.compare((double) o2.getAttribute("CDl"), (double) o1.getAttribute("CDl"));
				} else {
					// Sort by CDu in descending order
					return Double.compare((double) o2.getAttribute("CDu"), (double) o1.getAttribute("CDu"));
				}
			}
		});
	}

	public void addToAchive(Solution solution, List<Solution> archive, char flag) {
		Iterator<Solution> iterator = archive.iterator();
		while (iterator.hasNext()) {
			Solution oldSolution = iterator.next();
			int result = DominanceComparator.dominanceCompare(solution, oldSolution, flag);
			if (result < 0) {
				iterator.remove();
			} else if (result > 0) {
				return;
			} else if (compareObjectives(solution, oldSolution, flag)) {
				return;
			}
		}
		archive.add(solution.copy());
	}

	private boolean compareObjectives(Solution s1, Solution s2, char flag) {
		if (flag == 'u') {
			for (int i = 0; i < 2; i++) {
				if (s1.getUpperObjective(i) != s2.getUpperObjective(i)) {
					return false;
				}
			}
		} else {
			for (int i = 0; i < 2; i++) {
				if (s1.getLowerObjective(i) != s2.getLowerObjective(i)) {
					return false;
				}
			}
		}
		return true;
	}

	public void calcRankAndDistance(List<Solution> solutionSet, char flag) {
		ranking.computeRank(solutionSet, flag);
		for (int i = 0; i < ranking.getNumberOfSubfronts(); i++) {
			CrowdingDistance.computeCrowdingDistance(ranking.getSubfront(i), flag);
		}
	}

	public void initializePopulation() {
		for (int i = 0; i < Nu; i++) {
			List<Solution> popI = new ArrayList<>(Nl);
			Solution s = new Solution(problem);
			problem.randomCreateUpperVar(s);
			for (int j = 0; j < Nl; j++) {
				problem.randomCreateLowerVar(s);
				popI.add(s.copy());
			}
			population.add(popI);
		}
	}

	public List<Solution> mergePopulation(List<List<Solution>> population) {
		List<Solution> mergedPopulation = new ArrayList<>();
		for (List<Solution> subPopulation : population) {
			mergedPopulation.addAll(subPopulation);
		}
		return mergedPopulation;
	}

	public void lowerEvaluatePop(List<Solution> pop) {
		for (Solution s : pop) {
			problem.evaluateLowerObj(s);
			problem.evaluateLowerConstraints(s);
			lowerEvaluations++;
		}
	}

	public void upperEvaluatePop(List<Solution> pop) {
		for (Solution s : pop) {
			problem.evaluateUpperObj(s);
			problem.evaluateUpperConstraints(s);
			upperEvaluations++;
		}
	}

}
