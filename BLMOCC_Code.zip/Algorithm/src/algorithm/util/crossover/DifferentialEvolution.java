package algorithm.util.crossover;

import java.util.List;

import basic.random.RandomGenerator;
import basic.solution.Solution;

/**
 * Differential evolution operator in upper and lower level
 * 
 */
public class DifferentialEvolution {

	private static final double DEFAULT_CR = 1.0;
	private static final double DEFAULT_F = 0.5;

	private double CR;
	private double F;

	/** Default constructor */
	public DifferentialEvolution() {
		this(DEFAULT_CR, DEFAULT_F);
	}

	/**
	 * Constructor
	 * 
	 * @param CR
	 * @param F
	 */
	public DifferentialEvolution(double CR, double F) {
		this.CR = CR;
		this.F = F;
	}

	public Solution crossoverUpper(List<Solution> parents) {
		Solution result;
		int jrand;	
		result = parents.remove(0).copy();
		int numberOfUpperVar = result.getProblem().getNumOfUpperVar();
		jrand = RandomGenerator.nextInt(0, numberOfUpperVar - 1);
		for (int j = 0; j < numberOfUpperVar; j++) {
			if (RandomGenerator.nextDouble(0, 1) < CR || j == jrand) {
				double value;
				value = result.getUpperVariableValue(j)
						+ F * (parents.get(0).getUpperVariableValue(j) - parents.get(1).getUpperVariableValue(j));
				if (result.getProblem().getName() == "DS3" && j == 0) {
					value = Math.ceil(value / 0.1) * 0.1;
				}

				if (value < result.getProblem().getLowerBound(j)) {
					value = result.getProblem().getLowerBound(j);
//							RandomGenerator.nextDouble(result.getProblem().getLowerBound(j),
//							result.getProblem().getUpperBound(j));
				}
				if (value > result.getProblem().getUpperBound(j)) {
					value = result.getProblem().getUpperBound(j);
//							RandomGenerator.nextDouble(result.getProblem().getLowerBound(j),
//							result.getProblem().getUpperBound(j));
				}
				result.setUpperVariableValue(j, value);
			}
		}
		return result;
	}

	public Solution crossoverLower(List<Solution> parents) {
		Solution result;
		int jrand;
		result = parents.remove(0).copy();
		int numberOfLowerVar = result.getProblem().getNumOfLowerVar();
		int numberOfUpperVar = result.getProblem().getNumOfUpperVar();
		jrand = RandomGenerator.nextInt(0, numberOfLowerVar - 1);
		for (int j = 0; j < numberOfLowerVar; j++) {
			if (RandomGenerator.nextDouble(0, 1) < CR || j == jrand) {
				double value;
				value = result.getLowerVariableValue(j)
						+ F * (parents.get(0).getLowerVariableValue(j) - parents.get(1).getLowerVariableValue(j));

				if (value < result.getProblem().getLowerBound(j + numberOfUpperVar)) {
					value = result.getProblem().getLowerBound(j + numberOfUpperVar);
//							RandomGenerator.nextDouble(result.getProblem().getLowerBound(j + numberOfUpperVar),
//							result.getProblem().getUpperBound(j + numberOfUpperVar));
				}
				if (value > result.getProblem().getUpperBound(j + numberOfUpperVar)) {
					value = result.getProblem().getUpperBound(j + numberOfUpperVar);
//							RandomGenerator.nextDouble(result.getProblem().getLowerBound(j + numberOfUpperVar),
//							result.getProblem().getUpperBound(j + numberOfUpperVar));
				}
				result.setLowerVariableValue(j, value);
			}
		}
		return result;
	}

	/**
	 * Getters and Setters
	 */
	public double getCR() {
		return CR;
	}

	public void setCR(double cR) {
		this.CR = cR;
	}

	public double getF() {
		return F;
	}

	public void setF(double f) {
		this.F = f;
	}

}
