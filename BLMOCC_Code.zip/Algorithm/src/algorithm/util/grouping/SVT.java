package algorithm.util.grouping;

import java.util.List;

import Jama.Matrix;
import Jama.SingularValueDecomposition;

public class SVT {
	
	private int iMax = 100;
	private double �� = 0.0001;

	/**
	 * Implementation of SVT algorithm
	 * @param M, an observed matrix; 
	 * @param indices, index set of observable elements.
	 * @return a completed matrix
	 */
	public Matrix singularValueThreshold(Matrix M, List<List<Integer>> indices) {
		int row = M.getRowDimension();
		int column = M.getColumnDimension();
		
		Matrix P = new Matrix(row, column); // position matrix
		for(int i = 0; i < indices.size(); i++) {
			P.set(indices.get(i).get(0), indices.get(i).get(1), 1);
		}
		double �� = P.arrayTimes(M).normF();
		double �� = 1.2*row*column/indices.size(); 
		double k0 = Math.ceil(��/(��*P.arrayTimes(M).norm2()));
		
		Matrix completedX = new Matrix(row, column);
		Matrix Y = P.arrayTimes(M).times(k0*��);
		
		for(int i = 1; i <= iMax; i++) {
			completedX = svsOperator(Y, ��);
			if(P.arrayTimes(completedX.minus(M)).normF()/P.arrayTimes(M).normF() < ��) {
				break;
			}
			Y = Y.plus(P.arrayTimes(M.minus(completedX)));
		}
		
		// Consider the calculation error
		for(int i = 0; i < row; i++) {
			for(int j = 0; j < column; j++) {
				if(completedX.getArray()[i][j] < Math.pow(10, -10)) {
					completedX.getArray()[i][j] = 0;
				}
			}
		}
		return completedX;
	}
	

	/**
	 * Singular value shrinkage operator
	 */
	public Matrix svsOperator(Matrix Y, double ��) {
		SingularValueDecomposition svd = Y.svd();
		Matrix U = svd.getU();
		Matrix V = svd.getV();
		double[] singularValue = svd.getSingularValues();
		for(int i = 0; i < singularValue.length; i++) {
			if(singularValue[i] >= ��) {
				singularValue[i] = singularValue[i] - ��;
			}else {
				singularValue[i] = 0;
			}
		}
		Matrix S = svd.getS();
		
		Matrix X = U.times(S).times(V.transpose());
		return X;
	}
}
