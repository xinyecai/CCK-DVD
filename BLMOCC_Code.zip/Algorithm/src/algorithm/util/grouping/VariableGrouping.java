package algorithm.util.grouping;

import java.util.ArrayList;
import java.util.List;

import Jama.Matrix;
import basic.random.RandomGenerator;
import basic.solution.Solution;

public class VariableGrouping {

	private Solution basicSolution;
	private int numOfUpperVar;
	private int numOfLowerVar;

	private List<Solution> upperVariedSolutions = new ArrayList<>();
	private List<Solution> lowerVariedSolutions = new ArrayList<>();
	private List<Solution> bothVariedSolutions = new ArrayList<>();

	private SVT svt = new SVT();

	// index set of observable elements
	private List<List<Integer>> indices = new ArrayList<>();
	private List<List<Integer>> groups = new ArrayList<>();
	private List<Integer> groupType = new ArrayList<>();

	public VariableGrouping(Solution basicSolution) {
		this.basicSolution = basicSolution;
		numOfUpperVar = basicSolution.getProblem().getNumOfUpperVar();
		numOfLowerVar = basicSolution.getProblem().getNumOfLowerVar();
	}

	// variable decomposition
	public void setGroups(Matrix[] mArray) {
		setIndices();
		for (int k = 1; k <= 2; k++) {// two objective
			for (int i = 0; i < numOfUpperVar; i++) {
				double delta1 = upperVariedSolutions.get(i).getLowerObjective(k - 1)
						- basicSolution.getLowerObjective(k - 1);
				for (int j = 0; j < numOfLowerVar; j++) {
					double delta2 = bothVariedSolutions.get(i * numOfLowerVar + j).getLowerObjective(k - 1)
							- lowerVariedSolutions.get(j).getLowerObjective(k - 1);
					double value = Math.abs(delta1 - delta2);

					mArray[k].set(i, j + numOfUpperVar, value);
					mArray[k].set(j + numOfUpperVar, i, value);
				}
			}
		}
		mArray[0] = mArray[1].plus(mArray[2]);
		double maxValue = getMaxValueOfMatrix(mArray[0]);
		if (maxValue != 0) {
			for (int i = 0; i < numOfUpperVar + numOfLowerVar; i++) {
				mArray[0].set(i, i, maxValue);
			}

			mArray[0] = svt.singularValueThreshold(mArray[0], indices);
			transformTo01Matrix(mArray[0]);
		}

		if (basicSolution.getProblem().getNumOfLowerConstraint() != 0) {
			Matrix m = new Matrix(numOfUpperVar + numOfLowerVar, numOfUpperVar + numOfLowerVar);
			for (int k = 0; k < basicSolution.getProblem().getNumOfLowerConstraint(); k++) {
				for (int i = 0; i < numOfUpperVar; i++) {
					double delta1 = upperVariedSolutions.get(i).getLowerConstraint(k)
							- basicSolution.getLowerConstraint(k);
					for (int j = 0; j < numOfLowerVar; j++) {
						double delta2 = lowerVariedSolutions.get(j).getLowerConstraint(k)
								- basicSolution.getLowerConstraint(k);
						double value = Math.abs(delta1 * delta2);
						m.set(i, j + numOfUpperVar, m.get(i, j + numOfUpperVar) + value);
						m.set(j + numOfUpperVar, i, m.get(j + numOfUpperVar, i) + value);
					}
				}
			}

			maxValue = getMaxValueOfMatrix(m);
			if (maxValue != 0) {
				for (int i = 0; i < numOfUpperVar + numOfLowerVar; i++) {
					m.set(i, i, maxValue);
				}
				m = svt.singularValueThreshold(m, indices);
				transformTo01Matrix(m);
				mArray[0] = logicalOr(mArray[0], m);
			}
		}
		depthFirstTraverse(mArray[0]);
	}

	public void depthFirstTraverse(Matrix m) {
		boolean[] visited = new boolean[numOfUpperVar + numOfLowerVar];
		List<Integer> singleGroup = new ArrayList<>();
		for (int i = 0; i < numOfUpperVar + numOfLowerVar; i++) {
			if (!visited[i]) {
				List<Integer> subGroup = new ArrayList<>();
				dfs(i, visited, subGroup, m);
				if (subGroup.size() == 1) {
					singleGroup.addAll(subGroup);
				} else {
					groups.add(subGroup);
				}
			}
		}

		if (singleGroup.size() > 0) {
			boolean flag = false;
			for (int num : singleGroup) {
				if (num < numOfUpperVar) {
					flag = true;
					groups.add(singleGroup);
					break;
				}
			}
			if (flag == false) {
				randomDivideLowerGroup(singleGroup);
			}
		}
	}

	public void dfs(int index, boolean[] visited, List<Integer> subGroup, Matrix m) {
		visited[index] = true;
		subGroup.add(index);
		for (int i = 0; i < numOfUpperVar + numOfLowerVar; i++) {
			if (m.getArray()[index][i] == 1 && !visited[i]) {
				dfs(i, visited, subGroup, m);
			}
		}
	}

	public void randomDivideLowerGroup(List<Integer> singleGroup) {
		if (singleGroup.size() > (numOfLowerVar - singleGroup.size()) / groups.size()) {
			List<Integer> subGroup;
			int average = (int) Math.floor((numOfLowerVar - singleGroup.size()) / groups.size());
			while (average < singleGroup.size()) {
				int ran = RandomGenerator.nextInt(average, singleGroup.size());
				subGroup = new ArrayList<>();
				for (int i = 0; i < ran; i++) {
					subGroup.add(singleGroup.remove(RandomGenerator.nextInt(0, singleGroup.size() - 1)));
				}
				if (subGroup.size() > 0) {
					groups.add(subGroup);
				}
			}
			if (singleGroup.size() > 0) {
				groups.add(singleGroup);
			}
		} else {
			groups.add(singleGroup);
		}
	}

	public Matrix logicalOr(Matrix m1, Matrix m2) {
		Matrix m = new Matrix(m1.getRowDimension(), m1.getColumnDimension());
		double[][] A = m.getArray();
		for (int i = 0; i < m.getRowDimension(); i++) {
			for (int j = 0; j < m.getColumnDimension(); j++) {
				A[i][j] = (int) m1.get(i, j) | (int) m2.get(i, j);
			}
		}
		return m;
	}

	public void transformTo01Matrix(Matrix m) {
		double mean = 0.0;
		int num = 0;
		for (int i = 0; i < numOfUpperVar + numOfLowerVar - 1; i++) {
			for (int j = i + 1; j < numOfUpperVar + numOfLowerVar; j++) {
				if (m.get(i, j) != 0) {
					mean += m.get(i, j);
					num++;
				}
			}
		}
		if (num != 0) {
			mean /= num;
			for (int i = 0; i < numOfUpperVar + numOfLowerVar; i++) {
				for (int j = 0; j < numOfUpperVar + numOfLowerVar; j++) {
					if (m.get(i, j) >= mean) {
						m.set(i, j, 1);
					} else {
						m.set(i, j, 0);
					}
				}
			}
		}
	}

	public double getMaxValueOfMatrix(Matrix m) {
		double maxValue = Double.NEGATIVE_INFINITY;
		for (int i = 0; i < m.getRowDimension(); i++) {
			for (int j = 0; j < m.getColumnDimension(); j++) {
				if (maxValue < m.get(i, j)) {
					maxValue = m.get(i, j);
				}
			}
		}
		return maxValue;
	}

	public void setGroupType() {
		for (int i = 0; i < groups.size(); i++) {
			boolean flag1 = false, flag2 = false;
			for (int num : groups.get(i)) {
				if (num < numOfUpperVar) {
					flag1 = true;
				} else {
					flag2 = true;
				}
			}
			if (flag1 == flag2) {
				groupType.add(3); // Type III
			} else if (flag1) {
				groupType.add(1); // Type I
			} else {
				groupType.add(2); // Type II
			}
		}
	}

	public void setUpperVariedSolutions() {
		for (int i = 0; i < numOfUpperVar; i++) {
			Solution s = basicSolution.copy();
			s.setUpperVariableValue(i, basicSolution.getUpperVariableValue(i) * 1.5);// ����Ϊ0�����Ǹ����ر�С����������
			upperVariedSolutions.add(s);
		}
	}

	public void setLowerVariedSolutions() {
		for (int j = 0; j < numOfLowerVar; j++) {
			Solution s = basicSolution.copy();
			s.setLowerVariableValue(j, basicSolution.getLowerVariableValue(j) * 1.5);
			lowerVariedSolutions.add(s);
		}
	}

	public void setBothVariedSolutions() {
		for (int i = 0; i < numOfUpperVar; i++) {
			for (int j = 0; j < numOfLowerVar; j++) {
				Solution s = basicSolution.copy();
				s.setUpperVariableValue(i, basicSolution.getUpperVariableValue(i) * 1.5);
				s.setLowerVariableValue(j, basicSolution.getLowerVariableValue(j) * 1.5);
				bothVariedSolutions.add(s);
			}
		}
	}

	public void setIndices() {
		for (int i = 0; i < numOfUpperVar + numOfLowerVar; i++) {
			addIndex(i, i);
		}
		for (int i = 0; i < numOfUpperVar; i++) {
			for (int j = 0; j < numOfLowerVar; j++) {
				addIndex(i, j + numOfUpperVar);
				addIndex(j + numOfUpperVar, i);
			}
		}
	}

	public void addIndex(int i, int j) {
		List<Integer> index = new ArrayList<>();
		index.add(i);
		index.add(j);
		indices.add(index);
	}

	public List<Solution> getUpperVariedSolutions() {
		return upperVariedSolutions;
	}

	public List<Solution> getLowerVariedSolutions() {
		return lowerVariedSolutions;
	}

	public List<Solution> getBothVariedSolutions() {
		return bothVariedSolutions;
	}

	public List<List<Integer>> getGroups() {
		return groups;
	}

	public List<Integer> getGroupType() {
		return groupType;
	}
}
