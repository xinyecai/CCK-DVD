package algorithm.util.indicator;

import java.util.Comparator;
import java.util.List;

import basic.solution.Solution;

/**
 * 
 * This class implements the calculation of HV
 * 
 */
public class Hypervolume {

	private static final double DEFAULT_OFFSET = 0.1;
	private double offset;

	/**
	 * Default constructor
	 */
	public Hypervolume() {
		this(DEFAULT_OFFSET);
	}

	public Hypervolume(double offset) {
		this.offset = offset;
	}

	/**
	 * Calculates hypervolume of a solution set, 
	 * REQUIRES: problem is bi-objective
	 * 
	 * @param flag	equal to 'l' or 'u', representing lower level or upper level
	 */
	public double calc2DHV(List<Solution> solutionSet, double[] nadirPoint, char flag) {
		double[] referencePoint = new double[2];
		for (int i = 0; i < 2; i++) {
			referencePoint[i] = nadirPoint[i] + offset;
		}

		double hv;
		if (solutionSet.size() == 0) {
			hv = 0.0;
		} else {
			// Sort the solution set, ascending by the first objective (or descending by the
			// second objective)
			solutionSet.sort(new Comparator<Solution>() {
				@Override
				public int compare(Solution o1, Solution o2) {
					if (flag == 'l') {
						return Double.compare(o1.getLowerObjective(0), o2.getLowerObjective(0));
					} else {
						return Double.compare(o1.getUpperObjective(0), o2.getUpperObjective(0));
					}
				}
			});

			if (flag == 'l') {
				hv = Math.abs((referencePoint[0] - solutionSet.get(0).getLowerObjective(0))
						* (referencePoint[1] - solutionSet.get(0).getLowerObjective(1)));
			} else {
				hv = Math.abs((referencePoint[0] - solutionSet.get(0).getUpperObjective(0))
						* (referencePoint[1] - solutionSet.get(0).getUpperObjective(1)));
			}

			for (int i = 1; i < solutionSet.size(); i++) {
				double temp;
				if (flag == 'l') {
					temp = Math.abs((referencePoint[0] - solutionSet.get(i).getLowerObjective(0))
							* (solutionSet.get(i - 1).getLowerObjective(1) - solutionSet.get(i).getLowerObjective(1)));
				} else {
					temp = Math.abs((referencePoint[0] - solutionSet.get(i).getUpperObjective(0))
							* (solutionSet.get(i - 1).getUpperObjective(1) - solutionSet.get(i).getUpperObjective(1)));
				}
				hv += temp;
			}
		}
		return hv;
	}

//	public double[] generateReferencePoint(double[] nadirPoint) {
//		double[] referencePoint = new double[2];// two objective problem
//		for(int i = 0; i < 2; i++) {
//			referencePoint[i] = nadirPoint[i] + offset;
//		}
//		return referencePoint;
//	}

	/** Getter and Setter */
	public double getOffset() {
		return offset;
	}

	public void setOffset(double offset) {
		this.offset = offset;
	}

}
