package algorithm.util.mutation;

import basic.problem.Problem;
import basic.random.RandomGenerator;
import basic.solution.Solution;

public class PolynomialMutation {

	private static final double DEFAULT_PROBABILITY = 0.01;// Pm
	private static final double DEFAULT_DISTRIBUTION_INDEX = 20.0;// ��

	private double mutationProbability; // Pm
	private double distributionIndex; // ��

	/** Default constructor */
	public PolynomialMutation() {
		this(DEFAULT_PROBABILITY, DEFAULT_DISTRIBUTION_INDEX);
	}

	/** Constructor */
	public PolynomialMutation(double mutationProbability, double distributionIndex) {
		this.mutationProbability = mutationProbability;
		this.distributionIndex = distributionIndex;
	}

	/** Constructor */
	public PolynomialMutation(Problem problem) {
		this(1.0 / (problem.getNumOfUpperVar() + problem.getNumOfLowerVar()), DEFAULT_DISTRIBUTION_INDEX);
	}

	public void mutationUpper(Solution s) {
		double upperBound, lowerBound, rand, sigmaK, power;

		int numberOfUpperVar = s.getProblem().getNumOfUpperVar();

		for (int i = 0; i < numberOfUpperVar; i++) {
			if (RandomGenerator.nextDouble(0, 1) <= mutationProbability) {
				double value = s.getUpperVariableValue(i);
				upperBound = s.getProblem().getUpperBound(i);
				lowerBound = s.getProblem().getLowerBound(i);
				power = 1.0 / (distributionIndex + 1);
				rand = RandomGenerator.nextDouble(0, 1);
				if (rand < 0.5) {
					sigmaK = Math.pow(2 * rand, power) - 1;
				} else {
					sigmaK = 1 - Math.pow(2 - 2 * rand, power);
				}
				if(s.getProblem().getName() == "Practical") {
					value += sigmaK;
				}else {
					value += sigmaK * (upperBound - lowerBound);
				}
				
				if (value < lowerBound) {
					value = lowerBound;
				}
				if (value > upperBound) {
					value = upperBound;
				}
				s.setUpperVariableValue(i, value);
			}
		}
	}

	public void mutationLower(Solution s) {
		double upperBound, lowerBound, rand, sigmaK, power;

		int numberOfLowerVar = s.getProblem().getNumOfLowerVar();
		int numberOfUpperVar = s.getProblem().getNumOfUpperVar();

		for (int i = 0; i < numberOfLowerVar; i++) {
			if (RandomGenerator.nextDouble(0, 1) <= mutationProbability) {
				double value = s.getLowerVariableValue(i);
				upperBound = s.getProblem().getUpperBound(i + numberOfUpperVar);
				lowerBound = s.getProblem().getLowerBound(i + numberOfUpperVar);
				power = 1.0 / (distributionIndex + 1);
				rand = RandomGenerator.nextDouble(0, 1);
				if (rand < 0.5) {
					sigmaK = Math.pow(2 * rand, power) - 1;
				} else {
					sigmaK = 1 - Math.pow(2 - 2 * rand, power);
				}
				if(s.getProblem().getName() == "Practical") {
					value += sigmaK;
				}else {
					value += sigmaK * (upperBound - lowerBound);
				}
				
				if (value < lowerBound) {
					value = lowerBound;
				}
				if (value > upperBound) {
					value = upperBound;
				}
				s.setLowerVariableValue(i, value);
			}
		}
	}

	/**
	 * Getters and setters
	 */
	public double getMutationProbability() {
		return mutationProbability;
	}

	public void setMutationProbability(double mutationProbability) {
		this.mutationProbability = mutationProbability;
	}

	public double getDistributionIndex() {
		return distributionIndex;
	}

	public void setDistributionIndex(double distributionIndex) {
		this.distributionIndex = distributionIndex;
	}

}
