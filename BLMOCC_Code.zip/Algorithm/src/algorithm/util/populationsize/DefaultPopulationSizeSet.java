package algorithm.util.populationsize;

import basic.problem.Problem;

public class DefaultPopulationSizeSet {

	public int getNu(Problem problem) {
		if (problem.getName() == "Practical") {
			return 10;
		} else if (problem.getName() == "DS1" || problem.getName() == "DS2" || problem.getName() == "DS3") {
			return 20;
		} else {
			return 5;
		}
	}

	public int getNl(Problem problem) {
		if (problem.getName() == "Practical") {
			return 10;
		} else if (problem.getName() == "TP2") {
			return 60;
		} else if (problem.getName() == "TP1" || problem.getName() == "TP3") {
			return 12;
		} else if (problem.getName() == "DS4" || problem.getName() == "DS5") {
			return 40;
		} else {
			return 20;
		}
	}

}
