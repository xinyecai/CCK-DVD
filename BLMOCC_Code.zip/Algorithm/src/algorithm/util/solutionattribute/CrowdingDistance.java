package algorithm.util.solutionattribute;

import java.util.*;

import basic.solution.Solution;

/**
 * This class implements the calculation of crowding distance
 * 
 */
public class CrowdingDistance {

	// Used for population sorting
	private static int index = 0;

	/**
	 * Calculate crowding distance value for solutions in the same front
	 * 
	 * @param flag	equal to 'l' or 'u', representing lower level or upper level
	 */
	public static void computeCrowdingDistance(List<Solution> solutionSet, char flag) {
		int size = solutionSet.size();
		if (size == 0) {
			return;
		}
		if (size == 1) {
			if (flag == 'l') {
				solutionSet.get(0).setAttribute("CDl", Double.POSITIVE_INFINITY);
			} else {
				solutionSet.get(0).setAttribute("CDu", Double.POSITIVE_INFINITY);
			}
			return;
		}
		if (size == 2) {
			if (flag == 'l') {
				solutionSet.get(0).setAttribute("CDl", Double.POSITIVE_INFINITY);
				solutionSet.get(1).setAttribute("CDl", Double.POSITIVE_INFINITY);
			} else {
				solutionSet.get(0).setAttribute("CDu", Double.POSITIVE_INFINITY);
				solutionSet.get(1).setAttribute("CDu", Double.POSITIVE_INFINITY);
			}
			return;
		}

		// Avoid changing the order of solutions in the original solutionSet
		List<Solution> newSet = new ArrayList<>(size);
		for (Solution s : solutionSet) {
			newSet.add(s);
		}
		for (int i = 0; i < size; i++) {
			if (flag == 'l') {
				newSet.get(i).setAttribute("CDl", 0.0);
			} else {
				newSet.get(i).setAttribute("CDu", 0.0);
			}
		}

		double objetiveMax;
		double objetiveMin;
		double distance;

		if (flag == 'l') {// lower level
			// only involve two objective problem
			for (int i = 0; i < 2; i++) {
				// Sort the population in ascending order according to lower level Obj i
				index = i;
				newSet.sort(new Comparator<Solution>() {
					@Override
					public int compare(Solution o1, Solution o2) {
						return Double.compare(o1.getLowerObjective(index), o2.getLowerObjective(index));
					}
				});

				objetiveMin = newSet.get(0).getLowerObjective(i);
				objetiveMax = newSet.get(newSet.size() - 1).getLowerObjective(i);

				newSet.get(0).setAttribute("CDl", Double.POSITIVE_INFINITY);
				newSet.get(size - 1).setAttribute("CDl", Double.POSITIVE_INFINITY);

				for (int j = 1; j < size - 1; j++) {
					distance = newSet.get(j + 1).getLowerObjective(i) - newSet.get(j - 1).getLowerObjective(i);
					distance = distance / (objetiveMax - objetiveMin);
					distance += (double) newSet.get(j).getAttribute("CDl");
					newSet.get(j).setAttribute("CDl", distance);
				}
			}
		} else {// upper level
			// only involve two objective problem
			for (int i = 0; i < 2; i++) {
				// Sort the population in ascending order according to upper level Obj i
				index = i;
				newSet.sort(new Comparator<Solution>() {
					@Override
					public int compare(Solution o1, Solution o2) {
						return Double.compare(o1.getUpperObjective(index), o2.getUpperObjective(index));
					}
				});

				objetiveMin = newSet.get(0).getUpperObjective(i);
				objetiveMax = newSet.get(newSet.size() - 1).getUpperObjective(i);

				newSet.get(0).setAttribute("CDu", Double.POSITIVE_INFINITY);
				newSet.get(size - 1).setAttribute("CDu", Double.POSITIVE_INFINITY);

				for (int j = 1; j < size - 1; j++) {
					distance = newSet.get(j + 1).getUpperObjective(i) - newSet.get(j - 1).getUpperObjective(i);
					distance = distance / (objetiveMax - objetiveMin);
					distance += (double) newSet.get(j).getAttribute("CDu");
					newSet.get(j).setAttribute("CDu", distance);
				}
			}
		}
	}

}
