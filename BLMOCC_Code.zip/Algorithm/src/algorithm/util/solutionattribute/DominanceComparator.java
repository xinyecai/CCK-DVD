package algorithm.util.solutionattribute;

import basic.solution.Solution;

/**
 * Compare the dominance relationship between two solutions according to
 * constrained-domination principle.
 * 
 */
public class DominanceComparator {
	
	
	/**
	 * @param flag	equal to 'l' or 'u', representing lower level or upper level
	 * 
	 * @return 0, non-dominated with each other;
	 * 		  -1, s1 dominates s2;
	 *         1, s2 dominates s1.
	 */
	public static int dominanceCompare(Solution s1, Solution s2, char flag) {
		
		double constraintViolationDegree1, constraintViolationDegree2;
		if(flag == 'l') {
			constraintViolationDegree1 = s1.getLowerConstraintViolationDegree();
			constraintViolationDegree2 = s2.getLowerConstraintViolationDegree();
		}else {
			constraintViolationDegree1 = s1.getUpperConstraintViolationDegree();
			constraintViolationDegree2 = s2.getUpperConstraintViolationDegree();
		}
		
		if(constraintViolationDegree1 < constraintViolationDegree2) {
			return -1;
		}else if(constraintViolationDegree1 > constraintViolationDegree2) {
			return 1;
		}else {
			boolean s1Dominates = false ;		 
			boolean s2Dominates = false ;
			double value1, value2;
			for(int i = 0; i < 2; i++) {// two objectives at upper and lower levels
				if(flag == 'l') {
					value1 = s1.getLowerObjective(i);
					value2 = s2.getLowerObjective(i);
				}else {
					value1 = s1.getUpperObjective(i);
					value2 = s2.getUpperObjective(i);
				}
				if (value1 < value2) {		        				 
					s1Dominates = true;
				} else if (value2 < value1) {		        			 
					s2Dominates = true;		      			 
				} 	      			 
			}
			if (s1Dominates == s2Dominates) {
				return 0;		    		 
			} else if (s1Dominates) {
				return -1;		    		 
			} else {
				return 1;		    		 
			}		    		 
		}
	}
}
