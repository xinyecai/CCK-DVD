package algorithm.util.solutionattribute;

import java.util.*;

import basic.solution.Solution;

/**
 * This class implements fast non-dominated sorting
 * 
 */
public class NonDominatedRanking {
	// Solutions stratified by non-dominated rank
	private List<List<Solution>> rankedPopulations;

//	public NonDominatedRanking() {
//		rankedPopulations = new ArrayList<>();
//	}

	/**
	 * Calculate non-dominated rank
	 * 
	 * @param flag	equal to 'l' or 'u', representing lower level or upper level
	 */
	public void computeRank(List<Solution> solutionSet, char flag) { 
		// Initialize
		int[] dominateMe = new int[solutionSet.size()];
		List<List<Integer>> iDominate = new ArrayList<>(solutionSet.size());
		List<List<Integer>> front = new ArrayList<>(solutionSet.size() + 1);

		for (int i = 0; i < solutionSet.size(); i++) {
			dominateMe[i] = 0;
			iDominate.add(new ArrayList<Integer>());
		}
		for (int i = 0; i < solutionSet.size() + 1; i++) {
			front.add(new ArrayList<Integer>());
		}

		// Pairwise comparison
		int flagDominate;
		for (int i = 0; i < solutionSet.size() - 1; i++) {
			for (int j = i + 1; j < solutionSet.size(); j++) {
				flagDominate = DominanceComparator.dominanceCompare(solutionSet.get(i), solutionSet.get(j), flag);
				if (flagDominate == -1) {
					iDominate.get(i).add(j);
					dominateMe[j]++;
				} else if (flagDominate == 1) {
					iDominate.get(j).add(i);
					dominateMe[i]++;
				}
			}
		}

		// Obtain the first front
		for (int i = 0; i < solutionSet.size(); i++) {
			if (dominateMe[i] == 0) {
				front.get(0).add(i);
				if (flag == 'l') {
					solutionSet.get(i).setAttribute("NDl", 0);
				} else {
					solutionSet.get(i).setAttribute("NDu", 0);
				}
			}
		}

		// Obtain the rest of fronts
		int i = 0;
		Iterator<Integer> it1, it2;
		while (front.get(i).size() != 0) {
			i++;
			it1 = front.get(i - 1).iterator();
			while (it1.hasNext()) {
				it2 = iDominate.get(it1.next()).iterator();
				while (it2.hasNext()) {
					int index = it2.next();
					dominateMe[index]--;
					if (dominateMe[index] == 0) {
						front.get(i).add(index);
						if (flag == 'l') {
							solutionSet.get(index).setAttribute("NDl", i);
						} else {
							solutionSet.get(index).setAttribute("NDu", i);
						}
					}
				}
			}
		}

		rankedPopulations = new ArrayList<>();
		// 0,1,2,...,i-1 fronts
		for (int j = 0; j < i; j++) {
			rankedPopulations.add(j, new ArrayList<Solution>(front.get(j).size()));
			it1 = front.get(j).iterator();
			while (it1.hasNext()) {
				rankedPopulations.get(j).add(solutionSet.get(it1.next()));
			}
		}
	}

	public List<Solution> getSubfront(int rank) {
		return rankedPopulations.get(rank);
	}

	public int getNumberOfSubfronts() {
		return rankedPopulations.size();
	}

}
