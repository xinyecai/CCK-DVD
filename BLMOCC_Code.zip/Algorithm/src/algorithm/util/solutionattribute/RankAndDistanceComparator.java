package algorithm.util.solutionattribute;

import basic.solution.Solution;

/**
 * Compare two solutions according to the non-dominated rank and crowding distance
 * 
 */
public class RankAndDistanceComparator {
	
	/**
	 * @param flag, equal to 'l' or 'u', representing lower level or upper level 
	 * @return -1, s1 is superior than s2;
	 *          1, s1 is inferior than s2;
	 *          0, no difference between s1 and s2.
	 */
	public static int rankAndDistanceCompare(Solution s1, Solution s2, char flag) {
		int result = rankCompare(s1, s2, flag);
		if(result == 0) {
			result = distanceCompare(s1, s2, flag);
		}
		
		return result;
	}

	/**
	 * @param flag, equal to 'l' or 'u', representing lower level or upper level 
	 * @return -1, s1 is superior than s2 in non-dominated rank;
	 *          1, s1 is inferior than s2 in non-dominated rank;
	 *          0, no difference between s1 and s2 in non-dominated rank.
	 */
	public static int rankCompare(Solution s1, Solution s2, char flag) {
		int result;
		int rank1, rank2;
		if (flag == 'l') {
			rank1 = (int) s1.getAttribute("NDl");
			rank2 = (int) s2.getAttribute("NDl");
		} else {
			rank1 = (int) s1.getAttribute("NDu");
			rank2 = (int) s2.getAttribute("NDu");
		}

		result = Integer.compare(rank1, rank2);
//		if (rank1 < rank2) {
//			result = -1;
//		} else if (rank1 > rank2) {
//			result = 1;
//		} else {
//			result = 0;
//		}

		return result;
	}
	
	/**
	 * @param flag, equal to 'l' or 'u', representing lower level or upper level 
	 * @return -1, s1 is superior than s2 in crowding distance;
	 *          1, s1 is inferior than s2 in crowding distance,
	 *          0, no difference between s1 and s2 in crowding distance.
	 */
	// Solutions s1 and s2 should be in the same front
	public static int distanceCompare(Solution s1, Solution s2, char flag) {
		int result;
		double distance1, distance2;
		if (flag == 'l') {
			distance1 = (double) s1.getAttribute("CDl");
			distance2 = (double) s2.getAttribute("CDl");
		} else {
			distance1 = (double) s1.getAttribute("CDu");
			distance2 = (double) s2.getAttribute("CDu");
		}
		
		result = Double.compare(distance2, distance1);
//		if (distance1 > distance2) {
//			result = -1;
//		} else if (distance1 < distance2) {
//			result = 1;
//		} else {
//			result = 0;
//		}
		
		return result;
	}

}
