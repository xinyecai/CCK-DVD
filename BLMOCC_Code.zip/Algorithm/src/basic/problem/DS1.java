package basic.problem;

import java.util.ArrayList;
import java.util.List;

import basic.solution.Solution;

/**
 * Class representing problem DS1
 * 
 */
public class DS1 extends Problem {

	// default value
	private double r = 0.1;
	private double �� = 1;
	private double �� = 1;
	private double �� = 1;

	/**
	 * Creates a default DS1 problem (10 upper level variables and 10 lower level
	 * variables)
	 */
	public DS1() {
		this(10);
	}

	public DS1(int K) {
		setNumOfUpperObj(2);
		setNumOfLowerObj(2);
		setNumOfUpperVar(K);
		setNumOfLowerVar(K);
		setNumOfUpperConstraint(0);
		setNumOfLowerConstraint(0);
		setName("DS1");

		List<Double> upperBound = new ArrayList<>(getNumOfUpperVar() + getNumOfLowerVar());
		List<Double> lowerBound = new ArrayList<>(getNumOfUpperVar() + getNumOfLowerVar());

		upperBound.add(4.0);
		lowerBound.add(1.0);
		for (int i = 1; i < getNumOfUpperVar() + getNumOfLowerVar(); i++) {
			upperBound.add(K + 0.0);
			lowerBound.add(-K + 0.0);
		}
		setUpperBound(upperBound);
		setLowerBound(lowerBound);
	}

	@Override
	public void evaluateUpperObj(Solution s) {
		double[] Xu = new double[getNumOfUpperVar()];
		double[] Xl = new double[getNumOfLowerVar()];
		double[] F = new double[2];

		for (int i = 0; i < getNumOfUpperVar(); i++) {
			Xu[i] = s.getUpperVariableValue(i);
		}
		for (int i = 0; i < getNumOfLowerVar(); i++) {
			Xl[i] = s.getLowerVariableValue(i);
		}

		double value1 = 0.0;
		double value2 = 0.0;

		for (int j = 1; j < getNumOfUpperVar(); j++) {
			value1 += Math.pow(Xu[j] - j / 2.0, 2);
		}
		for (int i = 1; i < getNumOfLowerVar(); i++) {
			value2 += Math.pow(Xl[i] - Xu[i], 2);
		}

		F[0] = 1 + r - Math.cos(�� * Math.PI * Xu[0]) + value1 + �� * value2
				- r * Math.cos(�� * (Math.PI / 2) * (Xl[0] / Xu[0]));
		F[1] = 1 + r - Math.sin(�� * Math.PI * Xu[0]) + value1 + �� * value2
				- r * Math.sin(�� * (Math.PI / 2) * (Xl[0] / Xu[0]));

		for (int i = 0; i < 2; i++) {
			s.setUpperObjective(i, F[i]);
		}
	}

	@Override
	public void evaluateLowerObj(Solution s) {
		double[] Xu = new double[getNumOfUpperVar()];
		double[] Xl = new double[getNumOfLowerVar()];
		double[] f = new double[2];

		for (int i = 0; i < getNumOfUpperVar(); i++) {
			Xu[i] = s.getUpperVariableValue(i);
		}
		for (int i = 0; i < getNumOfLowerVar(); i++) {
			Xl[i] = s.getLowerVariableValue(i);
		}

		double value1 = 0.0;
		for (int i = 1; i < getNumOfLowerVar(); i++) {
			value1 += Math.pow(Xl[i] - Xu[i], 2);
		}

		double value2 = 0.0;
		for (int i = 1; i < getNumOfLowerVar(); i++) {
			value2 += 10 * (1 - Math.cos(Math.PI / getNumOfLowerVar() * (Xl[i] - Xu[i])));
		}

		double value3 = 0.0;
		for (int i = 1; i < getNumOfLowerVar(); i++) {
			value3 += 10 * Math.abs(Math.sin(Math.PI / getNumOfLowerVar() * (Xl[i] - Xu[i])));
		}

		f[0] = Math.pow(Xl[0], 2) + value1 + value2;
		f[1] = Math.pow(Xl[0] - Xu[0], 2) + value1 + value3;

		for (int i = 0; i < 2; i++) {
			s.setLowerObjective(i, f[i]);
		}
	}

	@Override
	public void evaluateUpperConstraints(Solution s) {
		// No upper level constraint
		s.setUpperConstraintViolationDegree(0.0);
	}

	@Override
	public void evaluateLowerConstraints(Solution s) {
		// No lower level constraint
		s.setLowerConstraintViolationDegree(0.0);
	}

}
