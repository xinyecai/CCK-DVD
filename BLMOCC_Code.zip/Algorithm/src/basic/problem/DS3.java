package basic.problem;

import java.util.ArrayList;
import java.util.List;

import basic.random.RandomGenerator;
import basic.solution.Solution;

/**
 * Class representing problem DS3
 * 
 */
public class DS3 extends Problem {

	// default value
	private double r = 0.2;
	private double �� = 1;

	/**
	 * Creates a default DS3 problem (10 upper level variables and 10 lower level
	 * variables)
	 */
	public DS3() {
		this(10);
	}

	public DS3(int K) {
		setNumOfUpperObj(2);
		setNumOfLowerObj(2);
		setNumOfUpperVar(K);
		setNumOfLowerVar(K);
		setNumOfUpperConstraint(1);
		setNumOfLowerConstraint(1);
		setName("DS3");

		List<Double> upperBound = new ArrayList<>(getNumOfUpperVar() + getNumOfLowerVar());
		List<Double> lowerBound = new ArrayList<>(getNumOfUpperVar() + getNumOfLowerVar());

		for (int i = 0; i < getNumOfUpperVar(); i++) {
			upperBound.add(K + 0.0);
			lowerBound.add(0.0);
		}
		for (int i = getNumOfUpperVar(); i < getNumOfUpperVar() + getNumOfLowerVar(); i++) {
			upperBound.add(K + 0.0);
			lowerBound.add(-K + 0.0);
		}

		setUpperBound(upperBound);
		setLowerBound(lowerBound);
	}
	
	/**
	 * Since y1 is a multiple of 0.1, override this method 
	 */
	@Override
	public void randomCreateUpperVar(Solution s) {
		double y1 = 0.1*RandomGenerator.nextInt(0, 10*getNumOfUpperVar());
		s.setUpperVariableValue(0, y1);
		
		for (int i = 1; i < getNumOfUpperVar(); i++) {
			double value = RandomGenerator.nextDouble(getLowerBound(i), getUpperBound(i));
			s.setUpperVariableValue(i, value);
		}
	}

	@Override
	public void evaluateUpperObj(Solution s) {
		double[] Xu = new double[getNumOfUpperVar()];
		double[] Xl = new double[getNumOfLowerVar()];
		double[] F = new double[2];

		for (int i = 0; i < getNumOfUpperVar(); i++) {
			Xu[i] = s.getUpperVariableValue(i);
		}
		for (int i = 0; i < getNumOfLowerVar(); i++) {
			Xl[i] = s.getLowerVariableValue(i);
		}

		double value1 = 0.0, value2 = 0.0;
		for (int j = 2; j < getNumOfUpperVar(); j++) {
			value1 += Math.pow(Xu[j] - (j + 1) / 2.0, 2);
		}
		for (int i = 2; i < getNumOfUpperVar(); i++) {
			value2 += Math.pow(Xl[i] - Xu[i], 2);
		}

		double Ry = 0.1 + 0.15 * Math.abs(Math.sin(2 * Math.PI * (Xu[0] - 0.1)));
		double value3 = Math.atan((Xu[1] - Xl[1]) / (Xu[0] - Xl[0]));

		F[0] = Xu[0] + value1 + �� * value2 - Ry * Math.cos(4 * value3);
		F[1] = Xu[1] + value1 + �� * value2 - Ry * Math.sin(4 * value3);

		for (int i = 0; i < 2; i++) {
			s.setUpperObjective(i, F[i]);
		}
	}

	@Override
	public void evaluateLowerObj(Solution s) {
		double[] Xu = new double[getNumOfUpperVar()];
		double[] Xl = new double[getNumOfLowerVar()];
		double[] f = new double[2];

		for (int i = 0; i < getNumOfUpperVar(); i++) {
			Xu[i] = s.getUpperVariableValue(i);
		}
		for (int i = 0; i < getNumOfLowerVar(); i++) {
			Xl[i] = s.getLowerVariableValue(i);
		}

		double value = 0.0;
		for (int i = 2; i < getNumOfUpperVar(); i++) {
			value += Math.pow(Xl[i] - Xu[i], 2);
		}

		f[0] = Xl[0] + value;
		f[1] = Xl[1] + value;

		for (int i = 0; i < 2; i++) {
			s.setLowerObjective(i, f[i]);
		}
	}

	@Override
	public void evaluateUpperConstraints(Solution s) {
		double[] Xu = new double[getNumOfUpperVar()];
//		double[] Xl = new double[getNumOfLowerVar()];
		double[] G = new double[getNumOfUpperConstraint()];

		for (int i = 0; i < getNumOfUpperVar(); i++) {
			Xu[i] = s.getUpperVariableValue(i);
		}
//		for (int i = 0; i < getNumOfLowerVar(); i++) {
//			Xl[i] = s.getLowerVariableValue(i);
//		}

		 G[0] = -Xu[1] + 1 - Math.pow(Xu[0], 2);

		double upperConstraintViolationDegree = 0.0;
		for (int i = 0; i < getNumOfUpperConstraint(); i++) {
			s.setUpperConstraint(i, G[i]);
			if (G[i] > 0) {
				upperConstraintViolationDegree += G[i];
			}
		}
		s.setUpperConstraintViolationDegree(upperConstraintViolationDegree);

	}

	@Override
	public void evaluateLowerConstraints(Solution s) {
		double[] Xu = new double[getNumOfUpperVar()];
		double[] Xl = new double[getNumOfLowerVar()];
		double[] g = new double[getNumOfLowerConstraint()];

		for (int i = 0; i < getNumOfUpperVar(); i++) {
			Xu[i] = s.getUpperVariableValue(i);
		}
		for (int i = 0; i < getNumOfLowerVar(); i++) {
			Xl[i] = s.getLowerVariableValue(i);
		}

		g[0] = Math.pow(Xl[0] - Xu[0], 2) + Math.pow(Xl[1] - Xu[1], 2) - Math.pow(r, 2);

		double lowerConstraintViolationDegree = 0.0;
		for (int i = 0; i < getNumOfLowerConstraint(); i++) {
			s.setLowerConstraint(i, g[i]);
			if (g[i] > 0) {
				lowerConstraintViolationDegree += g[i];
			}
		}
		s.setLowerConstraintViolationDegree(lowerConstraintViolationDegree);
	}

}
