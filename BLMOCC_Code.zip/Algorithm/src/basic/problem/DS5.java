package basic.problem;

import java.util.ArrayList;
import java.util.List;

import basic.solution.Solution;

/**
 * Class representing problem DS5
 * 
 */
public class DS5 extends Problem {

	private int K;
	private int L;

	/**
	 * Creates a default DS5 problem (1 upper level variable and 5+4 lower level
	 * variables)
	 */
	public DS5() {
		this(5, 4);
	}

	public DS5(int K, int L) {
		this.K = K;
		this.L = L;
		setNumOfUpperObj(2);
		setNumOfLowerObj(2);
		setNumOfUpperVar(1);
		setNumOfLowerVar(K + L);
		setNumOfUpperConstraint(1);
		setNumOfLowerConstraint(0);
		setName("DS5");

		List<Double> upperBound = new ArrayList<>(getNumOfUpperVar() + getNumOfLowerVar());
		List<Double> lowerBound = new ArrayList<>(getNumOfUpperVar() + getNumOfLowerVar());

		upperBound.add(2.0);
		lowerBound.add(1.0);

		upperBound.add(1.0);
		lowerBound.add(0.0);

		for (int i = 2; i < getNumOfUpperVar() + getNumOfLowerVar(); i++) {
			upperBound.add(K + L + 0.0);
			lowerBound.add(-K - L + 0.0);
		}

		setUpperBound(upperBound);
		setLowerBound(lowerBound);
	}

	@Override
	public void evaluateUpperObj(Solution s) {
		double[] Xu = new double[getNumOfUpperVar()];
		double[] Xl = new double[getNumOfLowerVar()];
		double[] F = new double[2];

		for (int i = 0; i < getNumOfUpperVar(); i++) {
			Xu[i] = s.getUpperVariableValue(i);
		}
		for (int i = 0; i < getNumOfLowerVar(); i++) {
			Xl[i] = s.getLowerVariableValue(i);
		}

		double value = 0.0;
		for (int j = 1; j < K; j++) {
			value += Math.pow(Xl[j], 2);
		}

		F[0] = (1 - Xl[0]) * (1 + value) * Xu[0];
		F[1] = Xl[0] * (1 + value) * Xu[0];

		for (int i = 0; i < 2; i++) {
			s.setUpperObjective(i, F[i]);
		}

	}

	@Override
	public void evaluateLowerObj(Solution s) {
		double[] Xu = new double[getNumOfUpperVar()];
		double[] Xl = new double[getNumOfLowerVar()];
		double[] f = new double[2];

		for (int i = 0; i < getNumOfUpperVar(); i++) {
			Xu[i] = s.getUpperVariableValue(i);
		}
		for (int i = 0; i < getNumOfLowerVar(); i++) {
			Xl[i] = s.getLowerVariableValue(i);
		}

		double value = 0.0;
		for (int j = K; j < K + L; j++) {
			value += Math.pow(Xl[j], 2);
		}

		f[0] = (1 - Xl[0]) * (1 + value) * Xu[0];
		f[1] = Xl[0] * (1 + value) * Xu[0];

		for (int i = 0; i < 2; i++) {
			s.setLowerObjective(i, f[i]);
		}

	}

	@Override
	public void evaluateUpperConstraints(Solution s) {
		double[] Xu = new double[getNumOfUpperVar()];
		double[] Xl = new double[getNumOfLowerVar()];
		double[] G = new double[getNumOfUpperConstraint()];

		for (int i = 0; i < getNumOfUpperVar(); i++) {
			Xu[i] = s.getUpperVariableValue(i);
		}
		for (int i = 0; i < getNumOfLowerVar(); i++) {
			Xl[i] = s.getLowerVariableValue(i);
		}

		G[0] = -(1 - Xl[0]) * Xu[0] - 0.5 * Xl[0] * Xu[0] + 2 - 0.2 * Math.floor(5 * (1 - Xl[0]) * Xu[0] + 0.2);

		double upperConstraintViolationDegree = 0.0;
		for (int i = 0; i < getNumOfUpperConstraint(); i++) {
			s.setUpperConstraint(i, G[i]);
			if (G[i] > 0) {
				upperConstraintViolationDegree += G[i];
			}
		}
		s.setUpperConstraintViolationDegree(upperConstraintViolationDegree);

	}

	@Override
	public void evaluateLowerConstraints(Solution s) {
		// No lower level constraint
		s.setLowerConstraintViolationDegree(0.0);

	}

}
