package basic.problem;

import java.util.ArrayList;
import java.util.List;

import basic.random.RandomGenerator;
import basic.solution.Solution;

/**
 * Class representing a practical problem
 * 
 */
public class Practical extends Problem {

	public Practical() {
		setNumOfUpperObj(2);
		setNumOfLowerObj(2);
		setNumOfUpperVar(2);
		setNumOfLowerVar(3);
		setNumOfUpperConstraint(2);
		setNumOfLowerConstraint(3);
		setName("Practical");

		List<Double> upperBound = new ArrayList<>(getNumOfUpperVar() + getNumOfLowerVar());
		List<Double> lowerBound = new ArrayList<>(getNumOfUpperVar() + getNumOfLowerVar());

		for (int i = 0; i < getNumOfLowerVar() + getNumOfUpperVar(); i++) {
			upperBound.add(Double.MAX_VALUE);
			lowerBound.add(0.0);
		}
		setUpperBound(upperBound);
		setLowerBound(lowerBound);
	}

	
	@Override
	public void randomCreateUpperVar(Solution s) {
		for (int i = 0; i < getNumOfUpperVar(); i++) {
			double value = RandomGenerator.nextDouble(0, 100);
			s.setUpperVariableValue(i, value);
		}
	}

	@Override
	public void randomCreateLowerVar(Solution s) {
		for (int i = 0; i < getNumOfLowerVar(); i++) {
			double value = RandomGenerator.nextDouble(0, 100);
			s.setLowerVariableValue(i, value);
		}
	}
	
	
	@Override
	public void evaluateUpperObj(Solution s) {
		double[] Xu = new double[getNumOfUpperVar()];
		double[] Xl = new double[getNumOfLowerVar()];
		double[] F = new double[2];

		for (int i = 0; i < getNumOfUpperVar(); i++) {
			Xu[i] = s.getUpperVariableValue(i);
		}
		for (int i = 0; i < getNumOfLowerVar(); i++) {
			Xl[i] = s.getLowerVariableValue(i);
		}

		F[0] = Xu[0] + 9 * Xu[1] + 10 * Xl[0] + Xl[1] + 3 * Xl[2];
		F[1] = 9 * Xu[0] + 2 * Xu[1] + 2 * Xl[0] + 7 * Xl[1] + 4 * Xl[2];

		for (int i = 0; i < 2; i++) {
			s.setUpperObjective(i, -F[i]);
		}

	}

	@Override
	public void evaluateLowerObj(Solution s) {
		double[] Xu = new double[getNumOfUpperVar()];
		double[] Xl = new double[getNumOfLowerVar()];
		double[] f = new double[2];

		for (int i = 0; i < getNumOfUpperVar(); i++) {
			Xu[i] = s.getUpperVariableValue(i);
		}
		for (int i = 0; i < getNumOfLowerVar(); i++) {
			Xl[i] = s.getLowerVariableValue(i);
		}

		f[0] = 4 * Xu[0] + 6 * Xu[1] + 7 * Xl[0] + 4 * Xl[1] + 8 * Xl[2];
		f[1] = 6 * Xu[0] + 4 * Xu[1] + 8 * Xl[0] + 7 * Xl[1] + 4 * Xl[2];

		for (int i = 0; i < 2; i++) {
			s.setLowerObjective(i, f[i]);
		}

	}

	@Override
	public void evaluateUpperConstraints(Solution s) {
		double[] Xu = new double[getNumOfUpperVar()];
		double[] Xl = new double[getNumOfLowerVar()];
		double[] G = new double[getNumOfUpperConstraint()];

		for (int i = 0; i < getNumOfUpperVar(); i++) {
			Xu[i] = s.getUpperVariableValue(i);
		}
		for (int i = 0; i < getNumOfLowerVar(); i++) {
			Xl[i] = s.getLowerVariableValue(i);
		}

		G[0] = 3 * Xu[0] + 9 * Xu[1] + 9 * Xl[0] + 5 * Xl[1] + 3 * Xl[2] - 1039;
		G[1] = -4 * Xu[0] - Xu[1] + 3 * Xl[0] - 3 * Xl[1] + 2 * Xl[2] - 94;

		double upperConstraintViolationDegree = 0.0;
		for (int i = 0; i < getNumOfUpperConstraint(); i++) {
			s.setUpperConstraint(i, G[i]);
			if (G[i] > 0) {
				upperConstraintViolationDegree += G[i];
			}
		}
		s.setUpperConstraintViolationDegree(upperConstraintViolationDegree);

	}

	@Override
	public void evaluateLowerConstraints(Solution s) {
		double[] Xu = new double[getNumOfUpperVar()];
		double[] Xl = new double[getNumOfLowerVar()];
		double[] g = new double[getNumOfLowerConstraint()];

		for (int i = 0; i < getNumOfUpperVar(); i++) {
			Xu[i] = s.getUpperVariableValue(i);
		}
		for (int i = 0; i < getNumOfLowerVar(); i++) {
			Xl[i] = s.getLowerVariableValue(i);
		}

		g[0] = 3 * Xu[0] - 9 * Xu[1] - 9 * Xl[0] - 4 * Xl[1] - 61;
		g[1] = 5 * Xu[0] + 9 * Xu[1] + 10 * Xl[0] - Xl[1] - 2 * Xl[2] - 924;
		g[2] = 3 * Xu[0] - 3 * Xu[1] + Xl[1] + 5 * Xl[2] - 420;

		double lowerConstraintViolationDegree = 0.0;
		for (int i = 0; i < getNumOfLowerConstraint(); i++) {
			s.setLowerConstraint(i, g[i]);
			if (g[i] > 0) {
				lowerConstraintViolationDegree += g[i];
			}
		}
		s.setLowerConstraintViolationDegree(lowerConstraintViolationDegree);
	}

}
