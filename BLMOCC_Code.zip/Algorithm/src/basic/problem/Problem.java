package basic.problem;

import java.util.List;

import basic.random.RandomGenerator;
import basic.solution.Solution;

/**
 * Define the implementation of an abstract bilevel problem
 * 
 */
public abstract class Problem {
	/**
	 * The number of objectives, variables and constraints of the problem at the
	 * upper level and lower level
	 */
	private int numOfUpperObj;
	private int numOfLowerObj;// all equal 2 in researched problems
	
	private int numOfUpperVar;
	private int numOfLowerVar;
	private int numOfUpperConstraint;
	private int numOfLowerConstraint;

	// name of the problem
	private String name;

	/**
	 * Upper and lower bounds of all variable values (sort from upper level variable
	 * to lower level variable)
	 */
	private List<Double> upperBound;
	private List<Double> lowerBound;

	/**
	 * Evaluate objective values and constraint values
	 * 
	 * @param s
	 */
	public abstract void evaluateUpperObj(Solution s);

	public abstract void evaluateLowerObj(Solution s);

	public abstract void evaluateUpperConstraints(Solution s);

	public abstract void evaluateLowerConstraints(Solution s);

	/**
	 * Create upper level and lower level solutions randomly
	 */
	public void randomCreateUpperVar(Solution s) {
		for (int i = 0; i < numOfUpperVar; i++) {
			double value = RandomGenerator.nextDouble(lowerBound.get(i), upperBound.get(i));
			s.setUpperVariableValue(i, value);
		}
	}

	public void randomCreateLowerVar(Solution s) {
		for (int i = 0; i < numOfLowerVar; i++) {
			double value = RandomGenerator.nextDouble(lowerBound.get(i + numOfUpperVar),
					upperBound.get(i + numOfUpperVar));
			s.setLowerVariableValue(i, value);
		}
	}

	/**
	 * Getters and Setters
	 */
	public int getNumOfUpperObj() {
		return numOfUpperObj;
	}

	public void setNumOfUpperObj(int numOfUpperObj) {
		this.numOfUpperObj = numOfUpperObj;
	}

	public int getNumOfLowerObj() {
		return numOfLowerObj;
	}

	public void setNumOfLowerObj(int numOfLowerObj) {
		this.numOfLowerObj = numOfLowerObj;
	}

	public int getNumOfUpperVar() {
		return numOfUpperVar;
	}

	public void setNumOfUpperVar(int numOfUpperVar) {
		this.numOfUpperVar = numOfUpperVar;
	}

	public int getNumOfLowerVar() {
		return numOfLowerVar;
	}

	public void setNumOfLowerVar(int numOfLowerVar) {
		this.numOfLowerVar = numOfLowerVar;
	}

	public int getNumOfUpperConstraint() {
		return numOfUpperConstraint;
	}

	public void setNumOfUpperConstraint(int numOfUpperConstraint) {
		this.numOfUpperConstraint = numOfUpperConstraint;
	}

	public int getNumOfLowerConstraint() {
		return numOfLowerConstraint;
	}

	public void setNumOfLowerConstraint(int numOfLowerConstraint) {
		this.numOfLowerConstraint = numOfLowerConstraint;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getUpperBound(int index) {
		return upperBound.get(index);
	}

	public void setUpperBound(List<Double> upperBound) {
		this.upperBound = upperBound;
	}

	public double getLowerBound(int index) {
		return lowerBound.get(index);
	}

	public void setLowerBound(List<Double> lowerBound) {
		this.lowerBound = lowerBound;
	}

}
