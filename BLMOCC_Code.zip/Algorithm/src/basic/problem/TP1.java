package basic.problem;

import java.util.ArrayList;
import java.util.List;

import basic.solution.Solution;

/**
 * Class representing problem TP1
 * 
 */
public class TP1 extends Problem {

	public TP1() {
		setNumOfUpperObj(2);
		setNumOfLowerObj(2);
		setNumOfUpperVar(1);
		setNumOfLowerVar(2);
		setNumOfUpperConstraint(1);
		setNumOfLowerConstraint(1);
		setName("TP1");

		List<Double> upperBound = new ArrayList<>(getNumOfUpperVar() + getNumOfLowerVar());
		List<Double> lowerBound = new ArrayList<>(getNumOfUpperVar() + getNumOfLowerVar());
		
		upperBound.add(1.0);
		lowerBound.add(0.0);
		for (int i = 1; i < getNumOfUpperVar() + getNumOfLowerVar(); i++) {
			upperBound.add(1.0);
			lowerBound.add(-1.0);
		}
		setUpperBound(upperBound);
		setLowerBound(lowerBound);
	}

	@Override
	public void evaluateUpperObj(Solution s) {
		double[] Xu = new double[getNumOfUpperVar()];
		double[] Xl = new double[getNumOfLowerVar()];
		double[] F = new double[2];

		for (int i = 0; i < getNumOfUpperVar(); i++) {
			Xu[i] = s.getUpperVariableValue(i);
		}
		for (int i = 0; i < getNumOfLowerVar(); i++) {
			Xl[i] = s.getLowerVariableValue(i);
		}

		F[0] = Xl[0] - Xu[0];
		F[1] = Xl[1];

		for (int i = 0; i < 2; i++) {
			s.setUpperObjective(i, F[i]);
		}
	}

	@Override
	public void evaluateLowerObj(Solution s) {
//		double[] Xu = new double[getNumOfUpperVar()];
		double[] Xl = new double[getNumOfLowerVar()];
		double[] f = new double[2];

//		for(int i = 0; i < getNumOfUpperVar(); i++) {
//			Xu[i] = s.getUpperVariableValue(i);
//		}
		for (int i = 0; i < getNumOfLowerVar(); i++) {
			Xl[i] = s.getLowerVariableValue(i);
		}

		f[0] = Xl[0];
		f[1] = Xl[1];

		for (int i = 0; i < 2; i++) {
			s.setLowerObjective(i, f[i]);
		}
	}

	@Override
	public void evaluateUpperConstraints(Solution s) {
//		double[] Xu = new double[getNumOfUpperVar()];
		double[] Xl = new double[getNumOfLowerVar()];
		double[] G = new double[getNumOfUpperConstraint()];

//		for(int i = 0; i < getNumOfUpperVar(); i++) {
//			Xu[i] = s.getUpperVariableValue(i);
//		}
		for (int i = 0; i < getNumOfLowerVar(); i++) {
			Xl[i] = s.getLowerVariableValue(i);
		}

		G[0] = -1 - Xl[0] - Xl[1];

		double upperConstraintViolationDegree = 0.0;
		for (int i = 0; i < getNumOfUpperConstraint(); i++) {
			s.setUpperConstraint(i, G[i]);
			if (G[i] > 0) {
				upperConstraintViolationDegree += G[i];
			}
		}
		s.setUpperConstraintViolationDegree(upperConstraintViolationDegree);
	}

	@Override
	public void evaluateLowerConstraints(Solution s) {
		double[] Xu = new double[getNumOfUpperVar()];
		double[] Xl = new double[getNumOfLowerVar()];
		double[] g = new double[getNumOfLowerConstraint()];

		for (int i = 0; i < getNumOfUpperVar(); i++) {
			Xu[i] = s.getUpperVariableValue(i);
		}
		for (int i = 0; i < getNumOfLowerVar(); i++) {
			Xl[i] = s.getLowerVariableValue(i);
		}

		g[0] = -Math.pow(Xu[0], 2) + Math.pow(Xl[0], 2) + Math.pow(Xl[1], 2);

		double lowerConstraintViolationDegree = 0.0;
		for (int i = 0; i < getNumOfLowerConstraint(); i++) {
			s.setLowerConstraint(i, g[i]);
			if (g[i] > 0) {
				lowerConstraintViolationDegree += g[i];
			}
		}
		s.setLowerConstraintViolationDegree(lowerConstraintViolationDegree);
	}

}
