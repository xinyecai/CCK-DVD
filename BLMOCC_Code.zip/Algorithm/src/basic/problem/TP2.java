package basic.problem;

import java.util.ArrayList;
import java.util.List;

import basic.solution.Solution;

/**
 * Class representing problem TP2
 * 
 */
public class TP2 extends Problem {

	/**
	 * Creates a default TP2 problem (14 lower level variables)
	 */
	public TP2() {
		this(14);
	}

	public TP2(int K) {
		setNumOfUpperObj(2);
		setNumOfLowerObj(2);
		setNumOfUpperVar(1);
		setNumOfLowerVar(K);
		setNumOfUpperConstraint(0);
		setNumOfLowerConstraint(0);
		setName("TP2");

		List<Double> upperBound = new ArrayList<>(getNumOfUpperVar() + getNumOfLowerVar());
		List<Double> lowerBound = new ArrayList<>(getNumOfUpperVar() + getNumOfLowerVar());

		for (int i = 0; i < getNumOfUpperVar() + getNumOfLowerVar(); i++) {
			upperBound.add(2.0);
			lowerBound.add(-1.0);
		}
		setUpperBound(upperBound);
		setLowerBound(lowerBound);
	}

	@Override
	public void evaluateUpperObj(Solution s) {
		double[] Xu = new double[getNumOfUpperVar()];
		double[] Xl = new double[getNumOfLowerVar()];
		double[] F = new double[2];

		for (int i = 0; i < getNumOfUpperVar(); i++) {
			Xu[i] = s.getUpperVariableValue(i);
		}
		for (int i = 0; i < getNumOfLowerVar(); i++) {
			Xl[i] = s.getLowerVariableValue(i);
		}

		double value = 0.0;
		for (int i = 1; i < getNumOfLowerVar(); i++) {
			value += Math.pow(Xl[i], 2);
		}

		F[0] = Math.pow(Xl[0] - 1, 2) + value + Math.pow(Xu[0], 2);
		F[1] = Math.pow(Xl[0] - 1, 2) + value + Math.pow(Xu[0] - 1, 2);

		for (int i = 0; i < 2; i++) {
			s.setUpperObjective(i, F[i]);
		}
	}

	@Override
	public void evaluateLowerObj(Solution s) {
		double[] Xu = new double[getNumOfUpperVar()];
		double[] Xl = new double[getNumOfLowerVar()];
		double[] f = new double[2];

		for (int i = 0; i < getNumOfUpperVar(); i++) {
			Xu[i] = s.getUpperVariableValue(i);
		}
		for (int i = 0; i < getNumOfLowerVar(); i++) {
			Xl[i] = s.getLowerVariableValue(i);
		}

		double value = 0.0;
		for (int i = 1; i < getNumOfLowerVar(); i++) {
			value += Math.pow(Xl[i], 2);
		}

		f[0] = Math.pow(Xl[0], 2) + value;
		f[1] = Math.pow(Xl[0] - Xu[0], 2) + value;

		for (int i = 0; i < 2; i++) {
			s.setLowerObjective(i, f[i]);
		}
	}

	@Override
	public void evaluateUpperConstraints(Solution s) {
		// No upper level constraint
		s.setUpperConstraintViolationDegree(0.0);

	}

	@Override
	public void evaluateLowerConstraints(Solution s) {
		// No lower level constraint
		s.setLowerConstraintViolationDegree(0.0);
	}

}
