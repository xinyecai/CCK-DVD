package basic.random;

import java.util.Random;

public class RandomGenerator {
	private static Random rnd = new Random();
	
	public static int nextInt(int min, int max) {
		return min + rnd.nextInt(max - min + 1);
	}

	public static double nextDouble(double min, double max) {
		return min + rnd.nextDouble() * (max - min);
	}
	
	public static int randomSelect(int a, int b) {
		int[] arr = {a,b};
		return arr[rnd.nextInt(2)];
	}

//	public static double nextDouble() {
//		return nextDouble(0.0, 1.0);
//	}

}
