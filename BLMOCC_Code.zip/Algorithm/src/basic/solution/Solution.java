package basic.solution;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import basic.problem.Problem;

/**
 * Define the implementation of a bilevel solution
 *
 */
public class Solution {

	private Problem problem;

	// upper and lower level objective values of a solution
	private double[] upperObjectives;
	private double[] lowerObjectives;

	// upper and lower level constraint values of a solution
	private double[] upperConstraints;
	private double[] lowerConstraints;

	// upper level solution and lower level solution
	private List<Double> upperVariables;
	private List<Double> lowerVariables;

	// store NDu, CDu,..., and other attributes of a solution
	private HashMap<Object, Object> attributes;

	// the overall constraint violation degree of a solution in the upper and lower
	// levels
	private double upperConstraintViolationDegree;
	private double lowerConstraintViolationDegree;

	/** Constructor */
	public Solution(Problem problem) {
		this.problem = problem;

		upperObjectives = new double[problem.getNumOfUpperObj()];
		lowerObjectives = new double[problem.getNumOfLowerObj()];

		upperConstraints = new double[problem.getNumOfUpperConstraint()];
		lowerConstraints = new double[problem.getNumOfLowerConstraint()];

		upperVariables = new ArrayList<>(problem.getNumOfUpperVar());
		for (int i = 0; i < problem.getNumOfUpperVar(); i++) {
			upperVariables.add(null);
		}

		lowerVariables = new ArrayList<>(problem.getNumOfLowerVar());
		for (int i = 0; i < problem.getNumOfLowerVar(); i++) {
			lowerVariables.add(null);
		}

		attributes = new HashMap<>();
	}

	/** Copy constructor */
	public Solution(Solution s) {
		this(s.getProblem());

		for (int i = 0; i < problem.getNumOfUpperObj(); i++) {
			setUpperObjective(i, s.getUpperObjective(i));
		}
		for (int i = 0; i < problem.getNumOfLowerObj(); i++) {
			setLowerObjective(i, s.getLowerObjective(i));
		}

		for (int i = 0; i < problem.getNumOfUpperConstraint(); i++) {
			setUpperConstraint(i, s.getUpperConstraint(i));
		}
		for (int i = 0; i < problem.getNumOfLowerConstraint(); i++) {
			setLowerConstraint(i, s.getLowerConstraint(i));
		}

		for (int i = 0; i < problem.getNumOfUpperVar(); i++) {
			setUpperVariableValue(i, s.getUpperVariableValue(i));
		}
		for (int i = 0; i < problem.getNumOfLowerVar(); i++) {
			setLowerVariableValue(i, s.getLowerVariableValue(i));
		}

		attributes = new HashMap<Object, Object>(s.attributes);
		upperConstraintViolationDegree = s.getUpperConstraintViolationDegree();
		lowerConstraintViolationDegree = s.getLowerConstraintViolationDegree();
	}

	/**
	 * Use the copy constructor to copy a solution
	 */
	public Solution copy() {
		return new Solution(this);
	}
	
	public boolean upperVarEquals(Solution s) {
		return this.upperVariables.equals(s.upperVariables);
		
	}
	public boolean lowerVarEquals(Solution s) {
		return this.lowerVariables.equals(s.lowerVariables);
	}

	/**
	 * Compare whether the two solutions are equal
	 */
	@Override
	public boolean equals(Object o) {
		if (o == null)
			return false;
		if (this == o)
			return true;

		if (o instanceof Solution) {
			Solution s = (Solution) o;
			if (!upperVarEquals(s))
				return false;
			if (!lowerVarEquals(s))
				return false;
			return true;
		}
		return false;
	}
	
	@Override
	public int hashCode() {
		int result = upperVariables.hashCode();
		result = 31*result + lowerVariables.hashCode();
		return result;
	}

	/**
	 * Getters and Setters
	 */
	public Problem getProblem() {
		return problem;
	}

	public double getUpperObjective(int index) {
		return upperObjectives[index];
	}

	public void setUpperObjective(int index, double value) {
		upperObjectives[index] = value;
	}

	public double getLowerObjective(int index) {
		return lowerObjectives[index];
	}

	public void setLowerObjective(int index, double value) {
		lowerObjectives[index] = value;
	}

	public double getUpperConstraint(int index) {
		return upperConstraints[index];
	}

	public void setUpperConstraint(int index, double value) {
		upperConstraints[index] = value;
	}

	public double getLowerConstraint(int index) {
		return lowerConstraints[index];
	}

	public void setLowerConstraint(int index, double value) {
		lowerConstraints[index] = value;
	}


	public double getUpperVariableValue(int index) {
		return upperVariables.get(index);
	}

	public void setUpperVariableValue(int index, double value) {
		upperVariables.set(index, value);
	}

	public double getLowerVariableValue(int index) {
		return lowerVariables.get(index);
	}

	public void setLowerVariableValue(int index, double value) {
		lowerVariables.set(index, value);
	}

	public void setAttribute(Object id, Object value) {
		attributes.put(id, value);
	}

	public Object getAttribute(Object id) {
		return attributes.get(id);
	}

	public double getUpperConstraintViolationDegree() {
		return upperConstraintViolationDegree;
	}

	public void setUpperConstraintViolationDegree(double upperConstraintViolationDegree) {
		this.upperConstraintViolationDegree = upperConstraintViolationDegree;
	}

	public double getLowerConstraintViolationDegree() {
		return lowerConstraintViolationDegree;
	}

	public void setLowerConstraintViolationDegree(double lowerConstraintViolationDegree) {
		this.lowerConstraintViolationDegree = lowerConstraintViolationDegree;
	}

}
