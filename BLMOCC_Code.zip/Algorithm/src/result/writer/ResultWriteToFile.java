package result.writer;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import basic.solution.Solution;
/**
 * Save the final result to a file
 *
 */
public class ResultWriteToFile{
	public static void saveResults(String filename, List<Solution> solutionSet) {
		try {
			FileWriter fw = new FileWriter(filename, false);
			for(Solution s : solutionSet) {
				for(int i = 0; i < 2; i++) {
					fw.write(String.valueOf(s.getUpperObjective(i)));
					fw.write(" ");
				}
				fw.write("\n");
			}
			fw.flush();
			fw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

